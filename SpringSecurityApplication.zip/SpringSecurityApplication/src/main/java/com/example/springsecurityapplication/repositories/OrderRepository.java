package com.example.springsecurityapplication.repositories;

import com.example.springsecurityapplication.enumm.Status;
import com.example.springsecurityapplication.models.Order;
import com.example.springsecurityapplication.models.Person;
import com.example.springsecurityapplication.models.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByPerson(Person person);

    //Поиск всех продуктов по части наименования продукта независимо от регистра
    List<Order> findByTitleContainingIgnoreCase(String title);

//    //Поиск по наименованию и фильтрация по диапозону цены
//    @Query(value = "select * from product where (lower(title) LIKE %?1%) or (lower(title) LIKE '?1%') or (lower(title) LIKE '%?1') and (price >= ?2 and price <= ?3)", nativeQuery = true)
//    List<Order> findByTitleAndPriceGreaterThanEqualAndPriceLessThanEqual(String title, float ot, float Do);
//
//    //Поиск по наименованию и фильтрация по диапозону цены. Сортировка по возрастанию цены (по умолчанию)
//    @Query(value = "select * from product where (lower(title) LIKE %?1%) or (lower(title) LIKE '?1%') or (lower(title) LIKE '%?1') and (price >= ?2 and price <= ?3) order by price", nativeQuery = true)
//    List<Order> findByTitleOrderByPriceAsc(String title, float ot, float Do);
//
//    //Поиск по наименованию и фильтрация по диапозону цены. Сортировка по убыванию цены
//    @Query(value = "select * from product where (lower(title) LIKE %?1%) or (lower(title) LIKE '?1%') or (lower(title) LIKE '%?1') and (price >= ?2 and price <= ?3) order by price desc", nativeQuery = true)
//    List<Order> findByTitleOrderByPriceDesc(String title, float ot, float Do);

    @Modifying
    @Query(value = "update orders set status=:status where id=:id", nativeQuery = true)
    int updateStatus(int id, String status);

}
